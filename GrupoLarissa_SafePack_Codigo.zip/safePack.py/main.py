from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import os
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database import Base  
from models import Morador, Funcionario, Cadastramento  
from typing import List
from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from models import Morador  
from database import get_db

# Nome da API
app = FastAPI()


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_methods=["*"],
    allow_headers=["*"],
)

# Obtendo o diretório base do projeto
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# Configuração do diretório de arquivos estáticos
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")


# Configuração do diretório de templates
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "front"))


# Endpoint para exibir a página principal
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# Endpoint para exibir a página de cadastro
@app.get("/cadastramento", response_class=HTMLResponse)
async def cadastramento(request: Request, db: Session = Depends(get_db)):
    apartamentos = db.query(Morador.num_apartamento).distinct().order_by(Morador.num_apartamento).all()
    return templates.TemplateResponse("cadastramento.html", {"request": request, "apartamentos": apartamentos})


@app.get("/retirada", response_class=HTMLResponse)
async def retirada(request: Request):
    return templates.TemplateResponse("retirada.html", {"request": request})


@app.get("/relatorio", response_class=HTMLResponse)
async def relatorio(request: Request):
    return templates.TemplateResponse("relatorio.html", {"request": request})


### Detalhes do banco de dados ###
@app.get("/api/moradores", response_model=List[Morador])
async def listar_moradores(db: Session = Depends(get_db)):
    moradores = db.query(Morador).all()
    return moradores

@app.get("/api/funcionarios", response_model=List[Funcionario])
async def listar_funcionarios(db: Session = Depends(get_db)):
    funcionarios = db.query(Funcionario).all()
    return funcionarios
