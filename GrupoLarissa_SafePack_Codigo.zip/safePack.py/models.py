from sqlalchemy import Column, Integer, String, Date, Boolean
from sqlalchemy.ext.declarative import declarative_base
from database import Base  

class Funcionario(Base):
    __tablename__ = "funcionario"
    id_cracha = Column(Integer, primary_key=True, index=True)
    cpf_funcionario = Column(String, unique=True, index=True)
    nome_funcionario = Column(String)
    tipo_func = Column(String)

class Morador(Base):
    __tablename__ = "morador"
    cpf_morador = Column(String, primary_key=True, index=True)
    num_apartamento = Column(Integer, index=True)
    torre = Column(String)
    nome_morador = Column(String)

class Cadastramento(Base):
    __tablename__ = "cadastramento"
    id = Column(Integer, primary_key=True, index=True)
    num_apartamento = Column(String, index=True)
    nome_morador = Column(String, index=True)
    data_chegada = Column(Date)
    recebido_por = Column(String)
    data_retirada = Column(Date, nullable=True)
    pessoa_retirada = Column(String, nullable=True)
    status = Column(Boolean, default=True)